﻿namespace AeDashboard
{
    public class AeDashboardConsts
    {
        public const string LocalizationSourceName = "AeDashboard";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
