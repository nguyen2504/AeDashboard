﻿using System.Collections.Generic;
using AeDashboard.Roles.Dto;

namespace AeDashboard.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<RoleListDto> Roles { get; set; }

        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}
