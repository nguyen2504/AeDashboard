﻿using AeDashboard.Configuration.Ui;

namespace AeDashboard.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}
